import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0bb543f7-7066-4b85-9999-80b1e126bb01")
public class Echéquier {
    @objid ("6bfb559e-7ca5-47b2-82b9-b99fa46ba4d5")
    public Case Attribute;

    @objid ("7c3909ca-9fe1-43fb-9f8a-9fa47c3dd62a")
    public void caseExiste(int case) {
    }

}
